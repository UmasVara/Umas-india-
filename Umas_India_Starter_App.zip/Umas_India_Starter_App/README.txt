UMAS.INDIA SHOPPING APP — STARTER PROTOTYPE

Included:
- Mobile-friendly pink/white storefront
- Home, Shop, product detail, size/colour selection
- Cart, demo checkout, local order history, profile/contact placeholder
- Example products and sample prices

How to try it on Android:
1. Extract the ZIP.
2. Open index.html in a browser that can open local HTML files, or open it on a computer.
3. It is a browser-based prototype, not yet a native Android APK.
4. Orders are stored only in that browser/device using localStorage. They are NOT sent to you.
5. Replace all sample products/prices with actual product information before any real use.

Not yet included:
- Seller/admin product management
- Online database or shared stock
- Real customer accounts
- Payments, shipping, notifications, live order tracking
- Native Android build/APK

This starter is intended for learning and design iteration. Do not collect sensitive customer data or accept payments through this demo.
